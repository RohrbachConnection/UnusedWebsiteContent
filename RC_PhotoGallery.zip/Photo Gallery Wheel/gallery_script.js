photoAmount = 7;
var photoDescriptions = [
"Herman Practicing",
"Pieter Practicing",
"Rohrbach Connection - Drums & Piano",
"Rohrbach Connection @ HUBspot Leiden",
"Rohrbach Connection @ HUBspot Leiden",
"Christmas Time! - Van Der Valk, Sassenheim",
"Rohrbach Connection @ Van Der Valk Hotel"
];

var galleryLayout = 'rcGallery.html';


//-----------------------PAGE HANDLING------------------------//
function getLayout(name) {
    name = name + ' #wrapper';
    $("#dynamicContent").load(name);
}

function getLayoutSync(name, func) {
    name = name + ' #wrapper';
    $("#dynamicContent").load(name, func);
}


//-------------------------TEST FUNCTIONS------------------------------//
function changePage(){
	$("#place5").html('I changed the page');
}


//-----------------------AUDIO FUNCTIONS---------------------------//
function audioSelect() {
    document.getElementById('audioSelect').play();
}


//------------------LOADING GALLERIES---------------------//
function goToGallery(){
    getLayout(galleryLayout);
}

function selectView() {
	if(document.getElementById("selectViewContent").className == 'showContent'){
		document.getElementById("selectViewContent").classList.remove("showContent");
		document.getElementById("selectViewContent").classList.toggle("hideContent");
	} else {
		document.getElementById("selectViewContent").classList.remove("hideContent");
		document.getElementById("selectViewContent").classList.toggle("showContent");
	}
}

function galleryStyleWheel(){
	if(document.getElementById("gallerySquare")){
		$('.photoSquareDescription').remove();
		
		var photosSquare = document.getElementsByClassName("photoSquare");
		for(var i = 0; i < photosSquare.length; i++){
			photosSquare[i].id = 'place' + (i+1);
			photosSquare[i].getAttribute('place');
			photosSquare[i].setAttribute('place', i);
		}
		
		$('.photoSquare').attr('class', 'photoWheel');
		
		$( '<div class="prevPhoto"><img src="pointer.png" onclick="prevPhoto()"/></div>' ).insertBefore( "#place1" );
		$( '<div class="nextPhoto"><img src="pointer.png" onclick="prevPhoto()"/></div>' ).insertAfter( "#place" + photoAmount);
		$( '<div id="photoDescription">Rohrbach Connection @ HUBspot Leiden</div>' ).insertAfter( "#place4" );
		
		$("#gallerySquare").attr('id', 'galleryWheel');
	} else {

	}	
}

function galleryStyleSquare(){
	if(document.getElementById("galleryWheel")){
		$('.prevPhoto').remove();
		$('.nextPhoto').remove();
		
		$('.photoWheel').removeAttr('id');
		$('.photoWheel').removeAttr('place');
		$('#photoDescription').remove();
		$('.photoWheel').attr('class', 'photoSquare');
		
		$( '<div class="photoSquareDescription"></div>' ).insertAfter( ".photoSquare" );
		
		$("#galleryWheel").attr('id', 'gallerySquare');
	} else {

	}
	
	
	photoDescriptionSquare();
}

//----------------NEXT AND PREVIOUS PHOTO HANDLING AND PHOTO DESCRIPTION--------------------//
function nextPhoto () {

	var photos = document.getElementsByClassName("photoWheel");
	for(var i = 0; i < photos.length; i++){
		
		var photoNum = parseInt(photos[i].getAttribute('photoNum'));
		
		if(photoNum == 1){
			var photoNum = parseInt(photos[i].getAttribute('photoNum'));
			photos[i].setAttribute('photoNum', photoAmount);
		} else {
			var photoNum = parseInt(photos[i].getAttribute('photoNum'));
			photos[i].setAttribute('photoNum', photoNum - 1);
		}
	}
	
	photoDescriptionWheel();
	audioSelect();

}

function prevPhoto(){
	var photos = document.getElementsByClassName("photoWheel");
	for(var i = 0; i < photos.length; i++){
		
		var photoNum = parseInt(photos[i].getAttribute('photoNum'));
		
		if(photoNum == photos.length){
			var photoNum = parseInt(photos[i].getAttribute('photoNum'));
			photos[i].setAttribute('photoNum', 1);
		} else {
			var photoNum = parseInt(photos[i].getAttribute('photoNum'));
			photos[i].setAttribute('photoNum', photoNum + 1);
		}
	}
	
	photoDescriptionWheel();
	audioSelect();
}

function photoDescriptionWheel(){
	var descr = document.getElementById('photoDescription');
	var place4 = document.getElementById("place4");
	photoNumber = parseInt(place4.getAttribute('photoNum'));
	
	descr.innerHTML = photoDescriptions[photoNumber - 1];
}

function photoDescriptionSquare(){
	var descriptionObject = document.getElementsByClassName("photoSquareDescription");
	for(var i = 0; i < descriptionObject.length; i++){
		descriptionObject[i].innerHTML = photoDescriptions[i];
	}
}